#include <iostream>     /* File: if-elseif-grade.cpp */
using namespace std;	

int main()              /* To determine your grade (fictitious) */
{
    char grade;         // Letter grade
    int mark;           // Numerical mark between 0 and 100
    cin >> mark;

	// if-else-if statement is used to check multiple conditions in order, from top to bottom.
	// Each condition is evaluated one at a time,
	// and as soon as a condition is found to be true, the corresponding block of code is executed,
	// and the rest of the conditions are skipped.
	// If none of the conditions are true, the optional else block (if present) will run as the default case.
	// Ensure the proper sequence

    if (mark >= 90) 
	    grade = 'A';    // mark >= 90
    else if (mark >= 60) 
	    grade = 'B';    // 90 > mark >= 60
    else if (mark >= 20)
    	grade = 'C';    // 60 > mark >= 20
    else if (mark >= 10) 
	    grade = 'D';    // 20 > mark >= 10
    else 
       grade = 'F';     // 10 > mark 

    cout << "Your letter grade is " << grade << endl;
    return 0;
}
