#include <iostream>     /* File: for-factorial.cpp */
using namespace std;	

/* To compute x! = x(x-1)(x-2)...1, where x is a non-negative integer */
int main() 
{
    int factorial = 1;
    int number;

    cout << "Enter a non-negative integer: ";
    cin >> number;

    /*
     * int j=1; j is counter used to control iterations
     * j <= number is the bool expression. When it is true, the statements will be executed.
     * ++j is the post-processing, which changes the counter and influence the values of boolean expression
     */
    for (int j = 1; j <= number; ++j) // Set up a counter to iterate
        factorial *= j;

    // for (int j = number; j > 0; --j)
    //     factorial *= j;
    
    cout << number << "! = " << factorial << endl;
    return 0;
}
