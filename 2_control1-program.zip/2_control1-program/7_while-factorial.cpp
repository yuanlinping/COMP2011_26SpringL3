#include <iostream>     /* File: while-factorial.cpp */
using namespace std;	

/* To compute x! = x(x-1)(x-2)...1, where x is a non-negative integer */

/* Example: 5!=5×4×3×2×1=120.
* Start with a number, e.g.,5.
* Multiply 5 by 4 , then by 3, then by 2, then by 1.
* Stop when the multiplier reaches 1.
 * */

/* solution:
 * Initialize a result variable
 * Multiply the result by the current number.
 * Reduce the number by 1, until the number reaches 1.
 */

int main()
{
    int factorial = 1;  // store the final result
    int number;

    cout << "Enter a non-negative integer: ";
    cin >> number;
    
    while (number > 0)
    {
        factorial *= number; // updated by multiplying it with the current value of number
        --number;            // decremented by 1 to move to the next smaller number
    }
    
    cout << factorial << endl;
    return 0;
}
