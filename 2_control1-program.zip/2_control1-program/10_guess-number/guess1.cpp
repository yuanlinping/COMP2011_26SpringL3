#include <iostream>     /* File: guess1.cpp */ 
using namespace std;

int main()              // 1st attempt: 1 player, 1 round 
{
    int number = 7;    // The answer is fixed beforehand
    int guess;

    cout << "Player 1, please enter your guess:" << endl;
    cin >> guess;

    if (guess == number)
        cout << "Player 1, your guess is correct :)" << endl;
    else
        cout << "Player 1, your guess is incorrect :(" << endl;

    return 0;
}
