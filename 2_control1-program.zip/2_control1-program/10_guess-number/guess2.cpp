#include <iostream>     /* File: guess1.cpp */
using namespace std;

int main()              // 1st attempt: 1 player, 1 round
{
    int number = 7;    // The answer is fixed beforehand
    int guess;

    cout << "Player 1, please enter your guess:" << endl;
    cin >> guess;

    // if-else-if statement
    if (guess == number)
        cout << "Player 1, your guess is correct :)" << endl;
    else if (guess < number)
        cout << "Sorry, your guess is smaller " << endl;
    else
        cout << "Sorry, your guess is bigger " << endl;

    // nested if
    if (guess == number)
        cout << "Player 1, your guess is correct :)" << endl;
    else {
        if (guess < number)
            cout << "Sorry, your guess is smaller " << endl;
        else
            cout << "Sorry, your guess is bigger " << endl;
    }
    return 0;
}
