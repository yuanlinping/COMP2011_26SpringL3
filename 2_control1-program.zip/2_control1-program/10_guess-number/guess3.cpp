#include <iostream>     /* File: guess2.cpp */ 
using namespace std;

int main()              // 2nd attempt: 1 player, multiple rounds
{
    int number = 7;    // The answer is fixed beforehand
    int guess;

    /**
     * Implementation with while statement
     */
    cout << "Player 1, please enter your guess:" << endl;
    cin >> guess;

    while (guess != number){
        if (guess == number)
            cout << "Player 1, you win!!!" << endl;

        else if (guess < number)
            cout << "Sorry, the number is bigger than "
                 << guess << endl;
        else 
            cout << "Sorry, the number is smaller than "
                 << guess << endl; 

        cout << "Player 1, please enter your guess:" << endl;
        cin >> guess;
    }


    /**
     * Implementation with do-while statement
     */

    do                  // Add a loop to implement multiple rounds
    {            
        cout << "Player 1, please enter your guess:" << endl;
        cin >> guess;

        if (guess == number)
            cout << "Player 1, you win!!!" << endl;
        else if (guess < number)
            cout << "Sorry, the number is bigger than " << guess << endl;
        else 
            cout << "Sorry, the number is smaller than " << guess << endl;
    } while (guess != number);  

    /**
     * The use of for-loop
     */

    for (; guess != number;) {
    cout << "Player 1, please enter your guess:" << endl;
    cin >> guess;

    if (guess == number)
        cout << "Player 1, you win!!!" << endl;
    else if (guess < number)
        cout << "Sorry, the number is bigger than " << guess << endl;
    else 
        cout << "Sorry, the number is smaller than " << guess << endl;
    }


    return 0;
}
