#include <iostream>     /* File: swap.cpp */
using namespace std;

int main() /* To sort 2 numbers so that the 2nd one is larger */
{
    int x, y;           // The input numbers

    cout << "Enter two integers (separated by whitespaces): ";
    cin >> x >> y;

    if (x > y)  // if statement
        cout << y << '\t' << x << endl;
    else
        cout << x << '\t' << y << endl;

    return 0;
}
