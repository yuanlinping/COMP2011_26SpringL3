// problem: turn marks into letter grades with the following rules:
// 'A': mark >= 90; 'B': 60 <= mark < 90; 'C': 20 <= mark < 60; 'D': 10 <= mark < 20; 'F': mark < 10

#include <iostream>
using namespace std;

int main()              /* To determine your grade (fictitious) */
{
    char grade;         // Letter grade
    int mark;           // Numerical mark between 0 and 100
    cin >> mark;

    // explicitly checks the entire range of conditions for each grade
    // Less efficient because all if statements are evaluated, even after one has already been satisfied.


    if (mark >= 90)
        grade = 'A';    // mark >= 90
    if (mark >= 60 && mark < 90)
        grade = 'B';    // 60 <= mark < 90
    if (mark >= 20 && mark < 60)
        grade = 'C';    // 20 <= mark < 60
    if (mark >= 10 && mark < 20)
        grade = 'D';    // 10 <= mark < 20
    if (mark < 10)
        grade = 'F';    // mark < 10

    cout << "Your letter grade is " << grade << endl;
    return 0;
}