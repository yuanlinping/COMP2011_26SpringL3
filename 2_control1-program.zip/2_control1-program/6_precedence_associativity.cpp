#include<iostream>
using namespace std;

int main() {
    int a = 5, b = 10, c = 15;
    int result = a + b > c && b % a == 0 || !c;

    cout << result << endl;
}




/*
a + b > c && b % a == 0 || （!c）

a + b > c && （b % a） == 0 || （!c）

（a + b） > c && （b % a） == 0 || （!c）

（（a + b） > c） && （b % a） == 0 || （!c）

（（a + b） > c） && （（b % a） == 0） || （!c）

（（（a + b） > c） && （（b % a） == 0）） || （!c）


（（a + b） > c） // 15 > 15 -> false
（（b % a） == 0）） // 10%5 == 0 -> true
（!c）// --> false
 (false && true) || false
 false || false --> false
 ****/