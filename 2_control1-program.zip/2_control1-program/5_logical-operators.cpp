#include <iostream>
using namespace std;

int main() {
    /**
     * The use of !
     * In a sunny day, you can hike.
     * Where should you put "You can hike." "You cannot hike."?
     */
    bool isRaining = false;

    if(!isRaining) {
        cout << "" << endl;
    } else {
        cout << "" << endl;
    }

    /**
     * The use of ||
     * NO classes in weekends or holidays.
     * Where should you put "No classes, take a rest!" "Oh you need to work hard for classes."?
     */

    bool isWeekend = true;
    bool isHoliday = false;

    if(isWeekend || isHoliday) {
        cout << "" << endl;
    } else {
        cout << "" << endl;
    }


    /**
     * The use of &&
     * You can only buy alcoholic drinks when you are above 18 and have an ID card.
     * Where should you put "Here is your drink" "You are not allowed to buy."?
     */
    int age = 20;
    bool hasID = true;

    if(age >= 18 && hasID) {
        cout << "" << endl;
    } else {
        cout << "" << endl;
    }

    return 0;
}
