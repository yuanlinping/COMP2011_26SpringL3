#include <iostream>     /* File: add-var.cpp */
using namespace std;

int main()              // Program's entry point
{
    // Define 2 variables, which are named memory location for a value
    // x, y are identifiers/names of the two variables
    // The vairables x, y hold the int values to add;
    int x, y;

    cout << "Please enter an integer: ";
    cin >> x;

    cout << "Please enter another integer: ";
    cin >> y;

    cout << x << " + " << y << " = " << x+y << endl; 

    return 0;           // A nice ending
}
