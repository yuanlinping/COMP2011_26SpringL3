#include <iostream>
#include <cmath> // For mathematical operations (like pow)
using namespace std;

int main() {
    // Declare variables
    int radius, area, circumference;  // declaration;
    const int PI = 3;  // Value of Pi

    // Prompt user for radius
    cout << "Enter the radius of the circle: ";
    cin >> radius;

    // Calculate area and circumference
    area = PI * pow(radius, 2);              // Area = π * r²
    circumference = 2 * PI * radius;         // Circumference = 2 * π * r

    // Display results
    cout << "For a circle with radius " << radius << ":" << endl;
    cout << "Area = " << area << endl;
    cout << "Circumference = " << circumference << endl;

    return 0;
}