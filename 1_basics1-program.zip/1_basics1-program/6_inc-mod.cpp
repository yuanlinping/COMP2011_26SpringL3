#include <iostream>     /* File: inc-mod.cpp */
using namespace std;	

int main() 
{
    int x = 100, y = 100; // Variable definitions and initialization
    int a = 10, b = 10, c = 10, d = 10;

    cout << ++x << "\t"; // 101
    cout << "x = " << x << endl; // x = 101
    cout << y++ << "\t"; // 100
    cout << "y = " << y << endl; // y = 101

    x = 100; y = 100;
    a = 10; b = 10; c = 10; d = 10;

    b = a + (x++) + ++y;   // b = 10 + 101 + 101 = 211; x = 101; y = 101

    a = ++b; // a = 212
    cout << "a = " << a << "\t" << "b = " << b << endl;
    c = d++; // c = 10; d = 11
    cout << "c = " << c << "\t" << "d = " << d << endl;
    
    return 0;
}
