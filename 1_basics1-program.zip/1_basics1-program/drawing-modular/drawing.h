#ifndef DRAWING_H
#define DRAWING_H

void drawLine();        // Function to draw a line
void drawCircle();      // Function to draw a circle (or another shape)

#endif