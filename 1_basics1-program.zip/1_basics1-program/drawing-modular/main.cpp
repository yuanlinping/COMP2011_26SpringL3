#include <iostream>
#include "drawing.h"

using namespace std;

int main() {
    std::cout << "Welcome to the Drawing Program!" << endl;

    // Call the functions
    drawLine();
    drawCircle();
    
    return 0;
}

// how to run the code in the terminal:
// g++ -std=c++11 -o drawing_program main.cpp drawing.cpp
// ./drawing.cpp
