#include <iostream>
#include "drawing.h"

using namespace std;

// Function to draw a line
void drawLine() {
    cout << "Drawing a line: ---------" << endl;
}

// Function to draw a circle (or simulate it with text)
void drawCircle() {
    cout << "Drawing a circle: " << endl;
    cout << "   ***   " << endl;
    cout << " *     * " << endl;
    cout << " *     * " << endl;
    cout << "   ***   " << endl;
}