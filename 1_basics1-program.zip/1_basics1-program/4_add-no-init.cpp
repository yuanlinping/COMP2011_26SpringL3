#include <iostream>     /* File: add-var.cpp */
using namespace std;

int main()              // Program's entry point
{
    int x = 1, y;
    y = 3;

    cout << x << " + " << y << " = " << x+y << endl;

    int m, n;

    cout << m << " + " << n << " = " << m+n << endl;

    return 0;           // A nice ending
}
