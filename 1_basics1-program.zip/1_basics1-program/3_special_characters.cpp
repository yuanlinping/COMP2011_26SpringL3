#include <iostream>
using namespace std;

int main() {
    cout << "S1: Hello World!" << endl;
    cout << "S2: Hello\nWorld!" << endl;
    cout << "S3: Hello\tWorld!" << endl;
    cout << "S4: Hello\bWorld!" << endl;
}