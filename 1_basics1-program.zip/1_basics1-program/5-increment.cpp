#include<iostream>
using namespace std;

int main(){
    /*
     * Pre- and post- Increment and Decrement Alone
     */ 
    int x = 5;
    cout << "After pre-increment (++x): " << ++x << endl;
    cout << "After pre-increment (x++): " << x++ << endl;
    cout << "Value of x after post-increment: " << x << endl;
    cout << endl;

    cout << "After pre-decrement (--x)" << --x << endl;
    cout << "After post-decrement (x--): " << x-- << endl;
    cout << "Value of x after post-decrement: " << x << endl;
    cout << endl << endl;

    /*
     * Increment and Decrement in Expressions
     */ 

    x = 10;
    int y;

    // Pre-increment in an expression
    y = ++x + 5;
    cout << "Using pre-increment (++x):" << endl;
    cout << "x = " << x << ", y = " << y << endl;

    // Reset x
    x = 10;

    // Post-increment in an expression
    y = x++ + 5;
    cout << "\nUsing post-increment (x++):" << endl;
    cout << "x = " << x << ", y = " << y << endl;
    cout << endl << endl;

    // complex calculation
    x = 3;
    cout << "inital value of x: " << x << endl;
    int result = (x++) + (++x) - (x--) + (--x);
    cout << "final x value after the expression: " << x << endl;
    cout << "result value: " << result << endl;

    return 0;
}