#include <iostream>
#include <cstring>
using namespace std;

// define a new data type named Location with Struct to represent a museum location
struct Location {
    char room[40]; // member
    int floor;
    char wall[20];  // e.g., "North", "South", "East", "West"
};

// define a new data type named Artwork with Struct to represent an artwork
struct Artwork {
    char title[20];
    char artist[20];
    char style[20];    // e.g., "Impressionism", "Post-Impressionism"
    double price;
    Location display;  // members can be basic data type or a user-defined data type
};

// Function to initialize artwork
void initArtwork(Artwork& art,
                const char title[20], const char artist[20],
                const char style[20], double price,
                const char room[40], int floor, const char wall[20]) {
    strcpy(art.title, title); // use the . Operator to access a struct member
    strcpy(art.artist, artist);
    strcpy(art.style, style);
    art.price = price;

    strcpy(art.display.room, room);
    art.display.floor = floor;
    strcpy(art.display.wall, wall);
}

// Function to initialize artwork
void initArtwork_2(Artwork& art,
                   const char title[20], const char artist[20],
                   const char style[20], double price,
                   const Location& loc) {
    strcpy(art.title, title);
    strcpy(art.artist, artist);
    strcpy(art.style, style);
    art.price = price;

    // struct-struct assignment
    art.display = loc;
}

// Function to display artwork information
void displayArtwork(const Artwork& art) {
    cout << "\nArtwork Details:" << endl;
    cout << "------------------------" << endl;
    cout << "Title: " << art.title << endl;
    cout << "Artist: " << art.artist << endl;
    cout << "Style: " << art.style << endl;
    cout << "Price: $" << art.price << " million" << endl;  // added price display
    cout << "Location: Room " << art.display.room
         << ", Floor " << art.display.floor
         << ", " << art.display.wall << " wall" << endl;
    cout << endl << endl << endl;
}

int main() {
    cout << "Musée d'Orsay Collection Management System" << endl;
    cout << "=========================================" << endl;

    // Method 1: initialized when it is defined using the initializer list with braces
    Artwork starryNight = {
        "Starry Night",
        "Vincent van Gogh",
        "Post-Impressionism",
        100.5,

        // nested Location initialization
        {"Impressionist Gallery",
            2,
            "East"}
    };

    // Method 2: Using memberwise assignment
    Artwork waterLilies;
    // access to the struct member with . operator
    strcpy(waterLilies.style, "Impressionism");
    strcpy(waterLilies.title, "Water Lilies"); // strcpy is from the cstring library
    strcpy(waterLilies.artist, "Claude Monet");
    waterLilies.price = 80.3;

    strcpy(waterLilies.display.room, "Monet Room");
    waterLilies.display.floor = 1;
    strcpy(waterLilies.display.wall, "West");

    // Method 3: Using initialization function
    Artwork balcony;
    initArtwork(balcony,
                "The Balcony",
                "Edouard Manet",
                "Impressionism",
                15.7,  // price in millions
                "Main Gallery",
                2,
                "North");

    // Method 3: Using initialization function
    Location degasGallery = {"Degas Gallery", 3, "West"};
    Artwork dancingClass;
    initArtwork_2(dancingClass,
              "Dancing Class",
              "Edgar Degas",
              "Impressionism",
              45.8,
              degasGallery);

    // Display Artwork Information
    cout << "\nArtwork information:" << endl;
    displayArtwork(balcony);
    displayArtwork(starryNight);
    displayArtwork(waterLilies);
    displayArtwork(dancingClass);

    // Method 4: Struct-to-struct assignment: Creating exhibition copy
    cout << "\nPreparing painting for special exhibition..." << endl;
    Artwork exhibitionStarryNight;
    exhibitionStarryNight = starryNight;

    // Modifying exhibition copy's location
    strcpy(exhibitionStarryNight.display.room, "Special Exhibition Hall");
    exhibitionStarryNight.display.floor = 1;
    strcpy(exhibitionStarryNight.display.wall, "East");

    return 0;
}