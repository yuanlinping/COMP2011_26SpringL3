#include <iostream>
#include <cstring>
using namespace std;

// define a new data type named Location with Struct to represent a museum location
struct Location {
    char room[40]; // member
    int floor;
    char wall[20];  // e.g., "North", "South", "East", "West"
};

// define a new data type named Artwork with Struct to represent an artwork
struct Artwork {
    char title[20];
    char artist[20];
    char style[20];    // e.g., "Impressionism", "Post-Impressionism"
    double price;
    Location display;  // members can be basic data type or a user-defined data type
};

// Function to display artwork information
void displayArtwork(const Artwork& art) {
    cout << "\nArtwork Details:" << endl;
    cout << "------------------------" << endl;
    cout << "Title: " << art.title << endl;
    cout << "Artist: " << art.artist << endl;
    cout << "Style: " << art.style << endl;
    cout << "Price: $" << art.price << " million" << endl;  // added price display
    cout << "Location: Room " << art.display.room
         << ", Floor " << art.display.floor
         << ", " << art.display.wall << " wall" << endl;
    cout << endl;
}

void displayExhibition(const Artwork exhibition[], int size) {
    cout << "\n=== Special Exhibition Gallery ===" << endl;
    cout << "Number of artworks: " << size << endl;
    double totalValue = 0;

    for (int i = 0; i < size; i++) {
        cout << "\nArtwork " << (i + 1) << ":" << endl;
        displayArtwork(exhibition[i]);
        totalValue += exhibition[i].price;
    }

    cout << "\nTotal Exhibition Value: $" << totalValue << " million" << endl;
}

// Function to find the most expensive artwork
void findMostExpensive(const Artwork exhibition[], int size) {
    int maxIndex = 0;
    for (int i = 1; i < size; i++) {
        if (exhibition[i].price > exhibition[maxIndex].price) {
            maxIndex = i;
        }

        // if (exhibition[i] > exhibition[maxIndex]) {
        //     maxIndex = i;
        // }
    }

    cout << "\nMost valuable artwork in the exhibition:" << endl;
    displayArtwork(exhibition[maxIndex]);
}

int main() {
    cout << "Musée d'Orsay Special Exhibition Management" << endl;
    cout << "=========================================" << endl;

    // Create a special exhibition location
    Location exhibitionHall = {"Special Exhibition Hall", 1, "East"};

    // Create an array of Artwork structures for the exhibition
    const int MAX_PAINTINGS = 3;
    Artwork impressionistExhibition[MAX_PAINTINGS] = {
        {"Water Lilies", "Claude Monet", "Impressionism", 80.3, exhibitionHall},
        {"The Balcony", "Edouard Manet", "Impressionism", 15.7, exhibitionHall},
        {"Starry Night", "Vincent van Gogh", "Post-Impressionism", 100.5, exhibitionHall},
    };

    // Display entire exhibition
    displayExhibition(impressionistExhibition, MAX_PAINTINGS);

    // Find and display the most expensive artwork
    findMostExpensive(impressionistExhibition, MAX_PAINTINGS);

    return 0;
}