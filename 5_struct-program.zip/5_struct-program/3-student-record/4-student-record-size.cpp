#include <iostream>     /* File: student-record-array.cpp */
using namespace std;

enum Dept { CSE, ECE, MATH }; /* File: student-record.h */

struct Date
{
    unsigned int year; // 4 bytes
    unsigned int month; // 4 bytes
    unsigned int day; // 4 bytes
};

struct Student_Record
{
    char name[32]; // 32
    unsigned int id; // 4
    char gender; // 1
    Dept dept; // 4
    Date entry; // 12
    // 32 + 4 + 1 + 4 + 12 = 53
    // 32 + 4 + 1 + 3 (padding) + 4 + 12 = 56
};

// Global constants for department names
const char dept_name[][30]
  = {"Computer Science", "Electrical Engineering", "Mathematics"};

void print_student_record(const Student_Record& x)
{
    // the width (extra spaces) will be added to the left of the value,
    // causing the value to be right-aligned.
    cout.width(12); cout << "name: " << x.name << endl;
    cout.width(12); cout << "id: " << x.id << endl;
    cout.width(12); cout << "gender: " << x.gender << endl;
    cout.width(12); cout << "dept: " << dept_name[x.dept] << endl;
    // cout.width(12); cout << "entry date: "; print_date(x.entry);
    cout<<endl;
}

int main() 
{
    Student_Record sr[] = {
        { "Adam",  12000, 'M', CSE,  { 2006, 1, 10 } },
        { "Bob",   11000, 'M', MATH, { 2005, 9, 1  } },
        { "Cathy", 10000, 'F', ECE,  { 2006, 8, 20 } }
    };

    cout << sizeof(sr) << endl; // 168
    cout << sizeof(Student_Record) << endl; // 56

    for (int j = 0; j < sizeof(sr)/sizeof(Student_Record); ++j)
        print_student_record(sr[j]);

    return 0;
}
