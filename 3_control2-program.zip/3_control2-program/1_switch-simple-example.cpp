#include <iostream>
using namespace std;

// switch statement allows multiple choices based on
// the value of an integral expression (integer, char, bool)

// When a case constant is matched, the statements associated with the case are executed until either
// a break statement; a return statement; the end of the switch statement

// compare with and without break statement

// compare break and return statement

// the use of default (optional)

int main() {
    int num = 4;
    switch (num%3) {
        case 0:cout<<"a";
        case 2:cout<<"b";
        // case 1:cout<<"c";
        default:
            cout<<"d";
    }

    cout << "\nEnd of the program." << endl;
    return 0;
}