#include <iostream>     /* File: multiplication-table.cpp */
#include <iomanip>      // a library that helps control input/output formats
using namespace std;

// compare break and continue
// A break causes the innermost enclosing loop to exit immediately.
// A continue causes the next iteration of the innermost enclosing loop to begin.

int main()
{

    for (int j = 1; j <= 5; ++j)
    {
        // if (j == 3) break;

        for (int k = 1; k <= 5; ++k)
        {
            // if (k==3) break;
            cout << setw(4) << j*k;
        }
        cout << endl;
    }

    return 0;
}
