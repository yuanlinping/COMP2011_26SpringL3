#include <iostream>
#include <cstring>
using namespace std;

const int MAX_NAME_LEN = 32;

// Class definition: data members + member functions + access control
class fish
{
private:
    /*** data members: ***/
    char name[MAX_NAME_LEN];
    unsigned int size;
    unsigned int food_eaten;

public:
    /*** member functions: ***/
    // Constructor
    fish(const char fish_name[], unsigned int initial_size)
    {
        strcpy(name, fish_name);
        size = initial_size;
        food_eaten = 0;
    }

    // ACCESSOR member functions: const => won’t modify data members
    const char* get_name() const { return name; }
    unsigned int get_size() const { return size; }
    unsigned int get_food_eaten() const { return food_eaten; }
    void print() const
    {
        cout << "Fish Name: " << name << endl;
        cout << "Size: " << size << endl;
        cout << "Food Eaten: " << food_eaten << endl;
    }

    // MUTATOR member functions: can modify data members
    void feed(unsigned int food_amount)
    {
        food_eaten += food_amount;
        size += food_amount / 2;
    }

};

// Main function to demonstrate the class
int main()
{
    // We can instantiate many objects from the class,
    // the objects share the same structure and behaviors.
    fish fish_1("Linda", 10);
    fish fish_2("Bob", 8);
    fish fish_3("Mary", 12);

    // Display initial states of all fish
    cout << "Before feeding:" << endl;
    fish_1.print();
    cout << endl;
    fish_2.print();
    cout << endl;
    fish_3.print();
    cout << endl;

    // Feed each fish different amounts of food
    fish_1.feed(5);
    fish_2.feed(3);
    fish_3.feed(7);

    // Display states of all fish after feeding
    cout << "\nAfter feeding:" << endl;
    fish_1.print();
    cout << endl;
    fish_2.print();
    cout << endl;
    fish_3.print();
    cout << endl;

    return 0;
}