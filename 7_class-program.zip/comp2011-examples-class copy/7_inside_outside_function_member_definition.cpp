#include <iostream>
#include <cstring>
using namespace std;

const int MAX_NAME_LEN = 32;

// Class definition
class fish
{
private:
    char name[MAX_NAME_LEN];
    unsigned int size;
    unsigned int food_eaten;

public:
    // Constructor (defined inside the class body)
    fish(const char fish_name[], unsigned int initial_size)
    {
        strcpy(name, fish_name);
        size = initial_size;
        food_eaten = 0;
    }

    // Defined within the class body, which are inline functions.
    const char* get_name() const { return name; }

    // Defined within the class body, which are inline functions.
    // the keyword inline is optional.
    inline unsigned int get_size() const { return size; }

    inline void print() const
    {
        cout << "Fish Name: " << name << endl;
        cout << "Size: " << size << endl;
        cout << "Food Eaten: " << food_eaten << endl;
    }

    // declare the function inside the body
    unsigned int get_food_eaten() const;
    void feed(unsigned int food_amount);
};

// Defined outside the class body
unsigned int fish::get_food_eaten() const
{
    return food_eaten;
}

void fish::feed(unsigned int food_amount)
{
    food_eaten += food_amount;
    size += food_amount / 2;
}

// Main function to demonstrate the class
int main()
{
    fish fish_1("Linda", 10);
    cout << "Before feeding:" << endl;
    fish_1.print();
    fish_1.feed(5);
    cout << "\nAfter feeding:" << endl;
    fish_1.print();

    return 0;
}