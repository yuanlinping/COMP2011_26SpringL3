#include <iostream>
#include <cstring>
using namespace std;

class fish
{
    private:
        char* name;               // Dynamic data member for the fish's name
        unsigned int size;
        unsigned int food_eaten;

    public:
        // Constructor with name and size
        fish(const char fish_name[], unsigned int initial_size)
        {
            // Dynamically allocate memory for the name
            name = new char[strlen(fish_name) + 1];
            strcpy(name, fish_name);

            size = initial_size;
            food_eaten = 0;
        }
        fish() {
            name = new char[1];
            name[0] = '\0';

            size = 10;
            food_eaten = 0;
        }

        // Destructor: releases the memory acquired by the object.
        // only one destructor in a class is allowed.

        ~fish()
        {
            cout << "Destructor called for fish: " << name << endl;
            delete[] name;
        }

        // ACCESSOR member functions
        const char* get_name() const { return name; }
        unsigned int get_size() const { return size; }
        unsigned int get_food_eaten() const { return food_eaten; }
        void print() const
        {
            cout << "Fish Name: " << name << endl;
            cout << "Size: " << size << endl;
            cout << "Food Eaten: " << food_eaten << endl;
        }

        // MUTATOR member functions
        void feed(unsigned int food_amount)
        {
            food_eaten += food_amount;
            size += food_amount / 2;
        }

        void set_name(const char new_name[])
        {
            // Release the old name memory
            delete[] name;

            // Allocate memory for the new name
            name = new char[strlen(new_name) + 1];
            strcpy(name, new_name);
        }
};

int main()
{
    // Create a fish object using the parameterized constructor
    fish fish_1("Linda", 10);

    cout << "Before feeding:" << endl;
    fish_1.print();

    fish_1.feed(5);

    cout << "\nAfter feeding:" << endl;
    fish_1.print();

    // Modify the fish's name using the mutator function
    fish_1.set_name("Sunshine");
    cout << "\nAfter renaming the fish:" << endl;
    fish_1.print();

    // Create another fish object using the default constructor
    fish fish_2;
    cout << "\nDefault constructor fish:" << endl;
    fish_2.print();

    // Set name and size for the default fish
    fish_2.set_name("Nemo");
    fish_2.feed(8);
    cout << "\nAfter modifying fish_2:" << endl;
    fish_2.print();

    return 0;

    // Question: when will the destructor be called?
}