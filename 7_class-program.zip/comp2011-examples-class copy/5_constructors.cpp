#include <iostream>
#include <cstring>
using namespace std;

const int MAX_NAME_LEN = 32;

// Class definition: data members + member functions + access control
class fish
{
    private:
        char name[MAX_NAME_LEN];
        unsigned int size;
        unsigned int food_eaten;

    public:
        // A constructor: is used to initialize the data members of an object when it is created.

        // Constructor without taking paramters: reserves an amount of memory big enough for an object of the class.
        fish() {}

        // Constructor with name
        fish(const char fish_name[])
        {
            strcpy(name, fish_name);
            size = 10;
            food_eaten = 0;
        }

        // Constructor with name and size
        fish(const char fish_name[], unsigned int initial_size)
        {
            strcpy(name, fish_name);
            size = initial_size;
            food_eaten = 0;
        }

        // ACCESSOR member functions: const => won’t modify data members
        const char* get_name() const { return name; }
        unsigned int get_size() const { return size; }
        unsigned int get_food_eaten() const { return food_eaten; }
        void print() const
        {
            cout << "Fish Name: " << name << endl;
            cout << "Size: " << size << endl;
            cout << "Food Eaten: " << food_eaten << endl;
        }

        // MUTATOR member functions: can modify data members
        void feed(unsigned int food_amount)
        {
            food_eaten += food_amount;
            size += food_amount / 2;
        }

        void set_name(const char fish_name[])
        {
            strcpy(name, fish_name);
        }

        void set_size(unsigned int new_size)
        {
            size = new_size;
        }

        void set_food_eaten(unsigned int new_food_eaten)
        {
            food_eaten = new_food_eaten;
        }

};

int main()
{
    // Instantiate a fish object using the default constructor
    fish fish_1;

    cout << "Fish 1 (Before setting values):" << endl;
    fish_1.print();

    fish_1.set_name("Linda");
    fish_1.set_size(10);
    fish_1.set_food_eaten(0);

    cout << "\nFish 1 (After Default Constructor):" << endl;
    fish_1.print();


    // Instantiate with the contructor with name and size
    fish fish_2("Nemo", 15);
    cout << "\nFish 2 (After Constructor with Name and Size):" << endl;
    fish_2.print();

    // Instantiate with the contructor with name
    fish fish_3("Bob");
    cout << "\nFish 3 (After Constructor with Name):" << endl;
    fish_3.print();

    return 0;
}