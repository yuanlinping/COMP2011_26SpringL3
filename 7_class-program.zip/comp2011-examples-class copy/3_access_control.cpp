#include <iostream>
#include <cstring>
using namespace std;

const int MAX_NAME_LEN = 32;

// Class definition: data members + member functions + access control
class fish
{
    private:  // accessible only to member functions of the class
        /*** data members: ***/
        char name[MAX_NAME_LEN];
        unsigned int size;
        unsigned int food_eaten;


    public: // accessible to any functions (both member functions of the class or other functions)
        /*** member functions: ***/
        // Constructor
        fish(const char fish_name[], unsigned int initial_size)
        {
            strcpy(name, fish_name);
            size = initial_size;
            food_eaten = 0;
        }

        // ACCESSOR member functions: const => won’t modify data members
        const char* get_name() const { return name; }
        unsigned int get_size() const { return size; }
        unsigned int get_food_eaten() const { return food_eaten; }
        void print() const
        {
            cout << "Fish Name: " << name << endl;
            cout << "Size: " << size << endl;
            cout << "Food Eaten: " << food_eaten << endl;
        }

        // MUTATOR member functions: can modify data members
        void feed(unsigned int food_amount)
        {
            food_eaten += food_amount;
            size += food_amount / 2;
        }

        void set_name(const char fish_name[]){
          strcpy(name, fish_name);
        }
};

// Main function to demonstrate the class
int main()
{
    // Create a fish object (instantiation)
    fish fish_1("Linda", 10);

    cout << "Before feeding:" << endl;
    fish_1.print();

    fish_1.feed(5);

    cout << "\nAfter feeding:" << endl;
    fish_1.print();

    // invalid and valid operations
     // cout << fish_1.name << endl; // invalid
     // cout << fish_1.get_name() << endl; // valid

     // cout << fish_1.size << endl;  // invalid
     // cout << fish_1.get_size() << endl;  // valid

    // how can we modify the name of the fish?
    // fish_1.name = "Mary"; // invalid

    // cout << "\nAfter changing the name:" << endl;
    // fish_1.set_name("Mary"); // valid
    // fish_1.print();

    // fish_1.size = 10; // invalid
    // fish_1.food_eaten = 10; // invalid
    // fish_1.feed(10); // valid

    return 0;
}