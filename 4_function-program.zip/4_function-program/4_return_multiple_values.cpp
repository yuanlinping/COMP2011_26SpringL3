#include <iostream>

struct Result {
    int integer;
    double decimal;
    char message;
};

Result getValues() {
    return {42, 3.14, 'D'}; // Use braces for initialization

}

int main() {
    Result result = getValues();
    std::cout << "Integer: " << result.integer << "\n";
    std::cout << "Double: " << result.decimal << "\n";
    std::cout << "Char: " << result.message << "\n";
    return 0;
}