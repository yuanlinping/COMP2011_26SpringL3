// An example of function definition, function call, and return

#include <iostream>

using namespace std;

// Function Definition
void drawLine() { // function header: return type, function name, formal parameter list
    // function body
    cout << "\nDrawing a line: ---------" << endl;
    return;  // (1) stop the function (2) return some values computed by the function
}

// Function Definition
void drawCircle() { // function header
    // function body
    drawLine();
    cout << "\nDrawing a circle: " << endl;
    cout << "   ***   " << endl;
    cout << " *     * " << endl;
    cout << " *     * " << endl;
    cout << "   ***   " << endl;
    return;
}

int main() {
    cout << "Welcome to the Drawing Program!" << endl;
            // Function Call: <function-name> ( <actual-parameter-list>)
    drawCircle();  // only when a function is called, the function will be executed.
    drawCircle();
    drawCircle();
    drawCircle();
    return 0;
}
