#include <iostream>
using namespace std;

int max(int a, int b) { return (a > b) ? a : b; }

void print_one_row(){

}

void print_leaves()
{
}

void print_trunk()
{
}

void print_pot()
{

}

void print_tree(){
    print_leaves();
    print_trunk();
    print_pot();
}

int main()
{
    print_tree();
    return 0;
}