#include <iostream>	/* File: draw-tree.cpp */
using namespace std;

void print_one_row(int num_leading_spaces, int num_symbols, char symbol)
{
    for (int j = 0; j < num_leading_spaces; ++j)
        cout << ' ';

    for (int j = 0; j < num_symbols; ++j)
        cout << symbol;

    cout << endl;
}

int main(){
  print_one_row(5, 6, '*');
  print_one_row(2, 4, '-');
  print_one_row(0, 9, '*');
}