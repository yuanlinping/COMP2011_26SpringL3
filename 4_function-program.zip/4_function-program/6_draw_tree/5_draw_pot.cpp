#include <iostream>	/* File: draw-tree.cpp */
using namespace std;

int max(int a, int b) { return (a > b) ? a : b; }

void print_one_row(int num_leading_spaces, int num_symbols, char symbol)
{
    for (int j = 0; j < num_leading_spaces; ++j)
        cout << ' ';

    for (int j = 0; j < num_symbols; ++j)
        cout << symbol;

    cout << endl;
}

void print_pot(int tree_width, int pot_height, int pot_base_width, char pot_symbol)
{
    int num_leading_spaces = (tree_width - pot_base_width) / 2;
    int num_symbol = pot_base_width;

    for (int row = pot_height; row > 0; --row)
    {
        print_one_row(num_leading_spaces, num_symbol, pot_symbol);
        ++num_leading_spaces;
        num_symbol -= 2;
    }
}

int main(){
    char pot_symbol;
    int tree_height;

    cout << "Enter the character symbols for pot:";
    cin >> pot_symbol;
    cout << "Enter height of the leaves (an odd integer, please): "<< endl;
    cin >> tree_height;

    int tree_width = 2*tree_height + 1;

    int pot_width = tree_width * 2/3;
    int pot_base_width = (pot_width % 2) ? pot_width : pot_width + 1;
    int pot_height = 3;

    print_pot(tree_width, pot_height, pot_base_width, pot_symbol);
}