#include <iostream>	/* File: draw-tree.cpp */
using namespace std;

int max(int a, int b) { return (a > b) ? a : b; }

void print_one_row(int num_leading_spaces, int num_symbols, char symbol)
{
    for (int j = 0; j < num_leading_spaces; ++j)
        cout << ' ';

    for (int j = 0; j < num_symbols; ++j)
        cout << symbol;

    cout << endl;
}

void print_trunk(int tree_width, int trunk_height, int trunk_width, char trunk_symbol)
{
    int num_leading_spaces = (tree_width - trunk_width)/2;

    for (int row = 0; row < trunk_height; ++row){
        print_one_row(num_leading_spaces, trunk_width, trunk_symbol);
    }
}

int main(){
    char trunk_symbol;
    int tree_height;

    cout << "Enter the character symbols for trunk:";
    cin >> trunk_symbol;
    cout << "Enter height of the leaves (an odd integer, please): "<< endl;
    cin >> tree_height;

    int tree_width = 2*tree_height + 1;
    int trunk_width = 3;
    int trunk_height = 3;

    print_trunk(tree_width, trunk_height, trunk_width, trunk_symbol);
}