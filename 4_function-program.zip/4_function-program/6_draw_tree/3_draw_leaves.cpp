#include <iostream>	/* File: draw-tree.cpp */
using namespace std;

void print_one_row(int num_leading_spaces, int num_symbols, char symbol)
{
    for (int j = 0; j < num_leading_spaces; ++j)
        cout << ' ';

    for (int j = 0; j < num_symbols; ++j)
        cout << symbol;

    cout << endl;
}

void print_leaves(int tree_height, char leaf_symbol)
{
  for (int row = 0, num_leading_spaces = tree_height;
       row < tree_height;
       ++row, --num_leading_spaces){
            print_one_row(num_leading_spaces, 2*row+1, leaf_symbol);
       }
}

int main(){
  char leaf_symbol;
  double tree_height;

  cout << "Enter the character symbols for leaves:";
  cin >> leaf_symbol;
  cout << "Enter height of the leaves (an odd integer, please): "<< endl;
  cin >> tree_height;

  print_leaves(tree_height, leaf_symbol);
}


