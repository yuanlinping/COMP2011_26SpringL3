#include<iostream>
using namespace std;

int max(int a, int b) { // formal parameter list: <datatype variable>,  <datatype variable>,...
  // one-on-one correspondence between the actual parameters (aka arguments)
  // and the formal parameters.
  // initialization: a = actual_a, b = actual_b

  int maxNum = a > b ? a : b;
  return maxNum, a, b;
}

int main(){
  cout << max(8, 7) << endl;  // actual parameters / arguments
  cout << max(5.0, 6.0) << endl;
}

