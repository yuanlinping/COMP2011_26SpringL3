/* File: pbv-swap.cpp */
#include <iostream>
using namespace std;

std::pair<int, int> swap_return(int a, int b) {
    int temp = a;
    a = b;
    b = temp;
    return std::make_pair(a, b); // Return the swapped values as a pair
}

// Pass-by-value
void swap(int a, int b)
{
    // A copy of the actual parameter is made and passed to the function.
    // The function works with this copy
    // so changes made inside the function do not affect the original value.
    int temp = a;
    a = b;
    b = temp;
}

// Pass-by-reference
void swap_2(int& a, int& b)
{
    // The actual parameter itself is passed to the function (via a reference).
    // The function works directly with the original object
    // so changes made inside the function will affect the original value.
    int temp = a;
    a = b;
    b = temp;
}

int main()
{
    int x = 10, y = 20;
    swap(x, y);
    cout << "(x , y) = " << '(' << x
         << " , " << y << ')' << endl;

    int m = 10, n = 20;
    swap_2(m, n);
    cout << "(m , n) = " << '(' << m
         << " , " << n << ')' << endl;

    int k = 10, l = 20;
    std::pair<int, int> result = swap_return(k, l);
    std::cout << "Swapped values: k = " << result.first << ", l = " << result.second << std::endl;
    return 0;
}
