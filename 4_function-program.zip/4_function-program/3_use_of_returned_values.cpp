#include<iostream>
using namespace std;

int max(int a, int b) { // formal parameter list: <datatype variable>,  <datatype variable>,...
    int maxNum = a > b ? a : b;
    return maxNum;
}

int main(){
    int sum = 10 + max(5, 6);
    cout<<sum<<endl;
}

