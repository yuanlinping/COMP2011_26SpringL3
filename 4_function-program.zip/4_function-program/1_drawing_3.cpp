// An example of how to write a function with formal/actual parameter lists
#include <iostream>

using namespace std;

void drawMultiLines(int lineNumber) {
    cout << "\nDrawing " << lineNumber << " lines:" << endl;
    for (int i = 1; i <= lineNumber; i++) {
        cout << "---------" << endl;
    }
    return;
}


int main() {
    cout << "Welcome to the Drawing Program!" << endl;

    // draw three lines
    cout << "\nDrawing " << 3 << " lines:" << endl;
    for (int i = 1; i <= 3; i++) {
        cout << "---------" << endl;
    }

    // draw four lines
    cout << "\nDrawing " << 4 << " lines:" << endl;
    for (int i = 1; i <= 4; i++) {
        cout << "---------" << endl;
    }
    return 0;
}
