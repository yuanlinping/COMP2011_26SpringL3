// An example of how to write a function with formal/actual parameter lists
#include <iostream>

using namespace std;

int main() {
    cout << "Welcome to the Drawing Program!" << endl;

    // draw three lines
    cout << "\nDrawing " << 3 << " lines:" << endl;
    for (int i = 1; i <= 3; i++) {
        cout << "---------" << endl;
    }

    // draw four lines
    cout << "\nDrawing " << 4 << " lines:" << endl;
    for (int i = 1; i <= 4; i++) {
        cout << "---------" << endl;
    }
    return 0;
}
