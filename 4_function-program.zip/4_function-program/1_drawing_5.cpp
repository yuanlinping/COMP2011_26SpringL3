// An example of formal and actual parameter lists
#include <iostream>
using namespace std;

void drawMultipleLine(int lineNumber) { // formal parameter list in function definition: <datatype variable>, ...
    // initialization: lineNumber = 3;
    // initialization: lineNumber = 4;
    cout << "\nDrawing " << lineNumber << " lines:" << endl;
    for (int i = 1; i <= lineNumber; i++) {
        cout << "---------" << endl;
    }
}

 int main() {
     cout << "Welcome to the Drawing Program!" << endl;

     drawMultipleLine(3); // actual parameter list in function call: <object>
     drawMultipleLine(4);

     for (int i = 1; i <= 5; i++) {
       drawMultipleLine(i);
     }

     return 0;
 }