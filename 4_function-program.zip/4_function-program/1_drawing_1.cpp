#include <iostream>

using namespace std;

int main() {
    cout << "Welcome to the Drawing Program!" << endl;

    cout << "\nDrawing a line: ---------" << endl;

    cout << "\nDrawing a circle: " << endl;
    cout << "   ***   " << endl;
    cout << " *     * " << endl;
    cout << " *     * " << endl;
    cout << "   ***   " << endl;

    cout << "\nDrawing a circle: " << endl;cout << "   ***   " << endl;
    cout << " *     * " << endl;
    cout << " *     * " << endl;
    cout << "   ***   " << endl;
}
