// An example of how to write a function with formal/actual parameter lists
#include <iostream>

using namespace std;

void drawMultipleLines(int lineNumber) {  // formal-parameter-list: <type1, variable1>, ...
    cout << "\nDrawing " << lineNumber << " lines:" << endl;
    for (int i = 1; i <= lineNumber; i++) {
        cout << "---------" << endl;
    }
}

int main() {
    cout << "Welcome to the Drawing Program!" << endl;

    drawMultipleLines(3);  // actual-parameter-list: <object1>, <object2>,...
    drawMultipleLines(4);

    return 0;
}
